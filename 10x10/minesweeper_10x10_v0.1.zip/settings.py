MAX_BOOM = 12
INF = 2 ** 63
